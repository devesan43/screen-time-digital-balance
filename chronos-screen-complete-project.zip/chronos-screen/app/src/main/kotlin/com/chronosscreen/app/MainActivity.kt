package com.chronosscreen.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AppOpsManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 17, 27)
    private val panel = Color.rgb(25, 34, 49)
    private val accent = Color.rgb(92, 156, 255)
    private val muted = Color.rgb(166, 180, 201)
    private lateinit var root: LinearLayout
    private lateinit var usageManager: UsageStatsManager
    private var range = Range.DAY
    private enum class Range { DAY, WEEK, MONTH }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usageManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(20, 24, 20, 24)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        text(root, "CHRONOS SCREEN", 24, Color.WHITE, true)
        text(root, "Your personal screen-time dashboard", 14, muted)
        space(root, 18)

        if (!hasUsageAccess()) {
            card(root) {
                text(this, "Usage access is required", 19, Color.WHITE, true)
                text(this, "Allow Chronos Screen to access app usage so it can calculate screen time and app opening counts. Your reports stay on this phone.", 14, muted)
                space(this, 12)
                button(this, "Grant Usage Access") {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            }
            text(root, "After enabling Chronos Screen in Android Usage Access settings, return to this app.", 13, muted)
            return
        }

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Daily", "Weekly", "Monthly").forEachIndexed { index, label ->
            button(tabs, label, index == range.ordinal) {
                range = Range.values()[index]
                render()
            }
        }
        root.addView(tabs)
        space(root, 12)

        val start = rangeStart(range)
        val end = System.currentTimeMillis()
        val usage = aggregate(start, end)
        val total = usage.values.sum()
        val launches = countLaunches(start, end)
        val targetMinutes = getSharedPreferences("chronos", MODE_PRIVATE).getInt("target_minutes", 240)
        val targetMs = targetMinutes * 60_000L

        card(root) {
            text(this, when(range) {
                Range.DAY -> "TODAY'S SCREEN TIME"
                Range.WEEK -> "THIS WEEK'S SCREEN TIME"
                Range.MONTH -> "THIS MONTH'S SCREEN TIME"
            }, 13, muted, true)
            text(this, formatDuration(total), 34, Color.WHITE, true)
            text(this, "App openings: $launches", 15, muted)
            space(this, 10)
            text(this, "Daily target: ${targetMinutes / 60}h ${targetMinutes % 60}m", 14, muted)
            val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal)
            progress.max = 100
            progress.progress = ((total.toDouble() / targetMs.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)
            addView(progress, LinearLayout.LayoutParams(-1, 12))
            space(this, 10)
            button(this, "Change daily target") { editTarget(targetMinutes) }
            if (range == Range.DAY && total >= targetMs) {
                text(this, "Daily target reached", 14, Color.rgb(255, 190, 90), true)
                showTargetNotification()
            }
        }

        space(root, 14)
        text(root, "MOST USED APPS", 18, Color.WHITE, true)
        text(root, "Ranked by foreground usage time", 13, muted)
        space(root, 8)

        val packages = packageManager.getInstalledApplications(0).associateBy { it.packageName }
        val ranked = usage.entries.sortedByDescending { it.value }.take(30)
        if (ranked.isEmpty()) {
            text(root, "No usage records found for this period yet.", 14, muted)
        } else {
            ranked.forEachIndexed { index, entry ->
                val app = packages[entry.key]
                val label = try { app?.let { packageManager.getApplicationLabel(it).toString() } ?: entry.key }
                            catch (_: Exception) { entry.key }
                card(root) {
                    val line = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val name = TextView(context).apply {
                        text = "${index + 1}. $label"
                        textSize = 15f
                        setTextColor(Color.WHITE)
                        maxLines = 1
                    }
                    line.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
                    val duration = TextView(context).apply {
                        text = formatDuration(entry.value)
                        textSize = 14f
                        setTextColor(muted)
                    }
                    line.addView(duration)
                    addView(line)
                }
            }
        }

        space(root, 14)
        button(root, "Export report as CSV") { exportCsv(ranked, packages, start, end, launches) }
        space(root, 8)
        button(root, "Refresh usage data") { render() }
        space(root, 14)
        text(root, "Privacy: Chronos Screen processes usage data locally. It does not send your app activity to a server.", 12, muted)
    }

    private fun aggregate(start: Long, end: Long): Map<String, Long> {
        val raw = usageManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyMap()
        val totals = mutableMapOf<String, Long>()
        raw.forEach { stat ->
            if (stat.totalTimeInForeground > 0) {
                totals[stat.packageName] = (totals[stat.packageName] ?: 0L) + stat.totalTimeInForeground
            }
        }
        return totals
    }

    private fun countLaunches(start: Long, end: Long): Int {
        val events = usageManager.queryEvents(start, end)
        val event = UsageEvents.Event()
        var count = 0
        var lastForegroundPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val isForeground = if (Build.VERSION.SDK_INT >= 29) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            if (isForeground && event.packageName != lastForegroundPackage) {
                count++
                lastForegroundPackage = event.packageName
            }
        }
        return count
    }

    private fun rangeStart(which: Range): Long {
        val c = Calendar.getInstance()
        when (which) {
            Range.DAY -> { c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0) }
            Range.WEEK -> { c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0) }
            Range.MONTH -> { c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0) }
        }
        return c.timeInMillis
    }

    private fun editTarget(current: Int) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText((current / 60).toString())
            hint = "Hours per day"
        }
        AlertDialog.Builder(this).setTitle("Daily target (hours)").setView(input)
            .setPositiveButton("Save") { _, _ ->
                val hours = input.text.toString().toIntOrNull()?.coerceIn(1, 24) ?: 4
                getSharedPreferences("chronos", MODE_PRIVATE).edit().putInt("target_minutes", hours * 60).apply()
                render()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showTargetNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val prefs = getSharedPreferences("chronos", MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (prefs.getString("alert_day", "") == today) return
        prefs.edit().putString("alert_day", today).apply()
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26)
            android.app.Notification.Builder(this, "target_alert")
        else android.app.Notification.Builder(this)
        manager.notify(101, builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Chronos Screen: daily target reached")
            .setContentText("You have reached your screen-time target for today.")
            .setContentIntent(intent).setAutoCancel(true).build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("target_alert", "Screen-time alerts", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun exportCsv(rows: List<Map.Entry<String, Long>>, apps: Map<String, ApplicationInfo>, start: Long, end: Long, launches: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "chronos-screen-report.csv")
        }
        val payload = buildString {
            append("App,Package,Foreground time (ms),Foreground time,Period start,Period end,App openings\n")
            rows.forEach { row ->
                val label = try { apps[row.key]?.let { packageManager.getApplicationLabel(it).toString() } ?: row.key }
                            catch (_: Exception) { row.key }
                append("\"${label.replace("\"", "\"\"")}\",\"${row.key}\",${row.value},\"${formatDuration(row.value)}\",$start,$end,$launches\n")
            }
        }
        pendingCsv = payload
        startActivityForResult(intent, 52)
    }

    private var pendingCsv: String = ""
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 52 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingCsv) }
                Toast.makeText(this, "CSV report exported", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun formatDuration(ms: Long): String {
        val minutes = ms / 60_000
        val hours = minutes / 60
        return if (hours > 0) "${hours}h ${minutes % 60}m" else "${minutes}m"
    }

    private fun text(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 4, 0, 4)
        })
    }

    private fun space(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun card(parent: LinearLayout, content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(panel)
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = 10
        parent.addView(box, params)
        box.content()
    }

    private fun button(parent: LinearLayout, label: String, selected: Boolean = false, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (selected) accent else Color.rgb(48, 62, 83)))
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(0, -2, 1f)
        p.setMargins(3, 3, 3, 3)
        parent.addView(b, p)
    }
}
