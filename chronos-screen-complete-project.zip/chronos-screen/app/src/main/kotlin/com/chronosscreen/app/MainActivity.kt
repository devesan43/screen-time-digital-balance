package com.chronosscreen.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AppOpsManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 26)
    private val panel = Color.rgb(24, 33, 49)
    private val accent = Color.rgb(77, 164, 255)
    private val cyan = Color.rgb(72, 220, 220)
    private val muted = Color.rgb(164, 180, 202)
    private lateinit var root: LinearLayout
    private lateinit var usageManager: UsageStatsManager
    private var range = Range.DAY
    private enum class Range { DAY, WEEK, MONTH }
    private var pendingPdf: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usageManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        createNotificationChannel()
        render()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 22, 18, 24) }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply { text = "⌛"; textSize = 34f; setTextColor(cyan); setPadding(0,0,12,0) }
        brand.addView(mark)
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(heading, "CHRONOS SCREEN", 22, Color.WHITE, true)
        addText(heading, "Take control of your digital day", 13, muted)
        brand.addView(heading); root.addView(brand); space(root, 18)

        if (!hasUsageAccess()) {
            card(root) {
                addText(this, "Welcome to Chronos", 21, Color.WHITE, true)
                addText(this, "To measure screen time and app openings, Android requires Usage Access permission. Chronos reads app-usage events only; it does not read messages, website history or page contents. Data stays on this phone.", 14, muted)
                space(this, 12)
                actionButton(this, "Enable Usage Access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            }
            addText(root, "In Android settings, select Chronos Screen and enable Permit usage access. Then return here.", 13, muted)
            return
        }

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Daily", "Weekly", "Monthly").forEachIndexed { i, label -> actionButton(tabs, label, range.ordinal == i) { range = Range.values()[i]; render() } }
        root.addView(tabs); space(root, 12)
        val start = rangeStart(range); val end = System.currentTimeMillis()
        val usage = aggregate(start, end).filter { it.value > 0 && it.key != packageName }
        val openings = countLaunchesByApp(start, end)
        val total = usage.values.sum()
        val target = getSharedPreferences("chronos", MODE_PRIVATE).getInt("target_minutes", 240)
        val targetMs = target * 60_000L

        card(root) {
            addText(this, when(range) { Range.DAY -> "TODAY'S SCREEN TIME"; Range.WEEK -> "THIS WEEK"; Range.MONTH -> "THIS MONTH" }, 12, muted, true)
            addText(this, formatDuration(total), 38, Color.WHITE, true)
            addText(this, "${openings.values.sum()} app openings", 14, cyan, true)
            space(this, 8)
            addText(this, "Daily limit: ${target / 60}h ${target % 60}m", 14, muted)
            val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal)
            progress.max = 100; progress.progress = ((total.toDouble() / targetMs.coerceAtLeast(1)) * 100).toInt().coerceIn(0,100)
            addView(progress, LinearLayout.LayoutParams(-1, 12)); space(this, 8)
            actionButton(this, "Set daily limit") { editTarget(target) }
            if (range == Range.DAY && total >= targetMs) addText(this, "Your daily screen-time limit has been reached.", 14, Color.rgb(255,190,90), true)
        }

        val ranked = usage.entries.sortedByDescending { it.value }
        val top = ranked.firstOrNull()
        val lateNight = calculateLateNight(start, end)
        val social = ranked.filter { isSocial(it.key) }.sumOf { it.value }
        space(root, 12); addText(root, "WELLBEING CHECK-IN", 17, Color.WHITE, true)
        card(root) {
            val insight = when {
                top == null -> "Your usage summary will appear after you use your apps."
                total >= targetMs -> "You've passed your daily limit. Consider a short screen-free break."
                social > total / 2 && total > 0 -> "Social apps take up more than half of your tracked time. Try setting a short check-in window."
                lateNight >= 30 * 60_000L -> "You used your phone for ${formatDuration(lateNight)} late at night. Consider a wind-down period before sleep."
                else -> "Good awareness starts with small choices. Take a 5-minute screen break between longer sessions."
            }
            addText(this, insight, 15, Color.WHITE, true)
            space(this, 6)
            if (top != null) addText(this, "Most-used app: ${appLabel(top.key)} (${formatDuration(top.value)})", 13, muted)
            addText(this, "Social app time: ${formatDuration(social)}  •  Late-night use: ${formatDuration(lateNight)}", 13, muted)
        }

        space(root, 12); addText(root, "APP ACTIVITY", 17, Color.WHITE, true)
        addText(root, "Ranked by time • app names shown instead of package IDs", 12, muted)
        ranked.take(30).forEachIndexed { i, entry ->
            val info = try { packageManager.getApplicationInfo(entry.key, 0) } catch (_: Exception) { null }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12,10,12,10) }
            if (info != null) {
                val icon = try { packageManager.getApplicationIcon(info) } catch (_: Exception) { null }
                if (icon != null) row.addView(ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(42,42))
            }
            val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10,0,0,0) }
            addText(names, "${i + 1}. ${appLabel(entry.key)}", 14, Color.WHITE, true)
            addText(names, "${openings[entry.key] ?: 0} openings", 11, muted)
            row.addView(names, LinearLayout.LayoutParams(0,-2,1f))
            addText(row, formatDuration(entry.value), 13, cyan, true)
            row.setBackgroundColor(panel); val p = LinearLayout.LayoutParams(-1,-2); p.bottomMargin = 7; root.addView(row,p)
        }
        if (ranked.isEmpty()) addText(root, "No usage records found for this period yet.", 14, muted)
        space(root, 10)
        actionButton(root, "Export PDF report") { exportPdf(ranked, openings, start, end, total) }
        space(root, 6); actionButton(root, "Refresh usage data") { render() }
        space(root, 14)
        addText(root, "Privacy: app usage data is processed locally. Chronos does not collect websites visited, messages or browsing history.", 11, muted)
    }

    private fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (_: Exception) { pkg.substringAfterLast('.') }
    private fun isSocial(pkg: String): Boolean = pkg in setOf("com.instagram.android","com.facebook.katana","com.facebook.orca","com.whatsapp","com.twitter.android","com.snapchat.android","com.linkedin.android","com.zhiliaoapp.musically")

    private fun aggregate(start: Long, end: Long): Map<String, Long> {
        val raw = usageManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyMap()
        val totals = mutableMapOf<String,Long>()
        raw.forEach { if (it.totalTimeInForeground > 0) totals[it.packageName] = (totals[it.packageName] ?: 0L) + it.totalTimeInForeground }
        return totals
    }

    private fun countLaunchesByApp(start: Long, end: Long): Map<String,Int> {
        val events = usageManager.queryEvents(start,end); val event = UsageEvents.Event(); val counts = mutableMapOf<String,Int>()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = if (Build.VERSION.SDK_INT >= 29) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED else event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            if (resumed && event.packageName != packageName) counts[event.packageName] = (counts[event.packageName] ?: 0) + 1
        }
        return counts
    }

    private fun calculateLateNight(start: Long, end: Long): Long {
        val events = usageManager.queryEvents(start,end); val e = UsageEvents.Event(); var total = 0L; var last: Long? = null
        while (events.hasNextEvent()) { events.getNextEvent(e); val fg = if (Build.VERSION.SDK_INT >= 29) e.eventType == UsageEvents.Event.ACTIVITY_RESUMED else e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            val bgEvent = if (Build.VERSION.SDK_INT >= 29) e.eventType == UsageEvents.Event.ACTIVITY_PAUSED || e.eventType == UsageEvents.Event.ACTIVITY_STOPPED else e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            if (fg) last = e.timeStamp else if (bgEvent && last != null) { val c = Calendar.getInstance().apply { timeInMillis = last!! }; if (c.get(Calendar.HOUR_OF_DAY) >= 23 || c.get(Calendar.HOUR_OF_DAY) < 6) total += (e.timeStamp - last!!).coerceAtLeast(0); last = null }
        }; return total
    }

    private fun rangeStart(which: Range): Long { val c = Calendar.getInstance(); when(which) { Range.DAY -> c.set(Calendar.HOUR_OF_DAY,0).also { c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) }; Range.WEEK -> c.set(Calendar.DAY_OF_WEEK,c.firstDayOfWeek).also { c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) }; Range.MONTH -> c.set(Calendar.DAY_OF_MONTH,1).also { c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) } }; return c.timeInMillis }

    private fun editTarget(current: Int) { val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText((current/60).toString()); hint = "Hours per day" }; AlertDialog.Builder(this).setTitle("Daily screen-time limit").setView(input).setPositiveButton("Save") { _,_ -> val h=input.text.toString().toIntOrNull()?.coerceIn(1,24) ?: 4; getSharedPreferences("chronos",MODE_PRIVATE).edit().putInt("target_minutes",h*60).apply(); render() }.setNegativeButton("Cancel",null).show() }

    private fun exportPdf(rows: List<Map.Entry<String,Long>>, opens: Map<String,Int>, start: Long, end: Long, total: Long) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE,"Chronos-Screen-Report.pdf") }
        pendingPdf = makePdf(rows,opens,start,end,total); startActivityForResult(intent,71)
    }
    private fun makePdf(rows: List<Map.Entry<String,Long>>, opens: Map<String,Int>, start: Long, end: Long, total: Long): ByteArray {
        val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val canvas=page.canvas; val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color=Color.rgb(16,25,42); canvas.drawColor(Color.WHITE); paint.color=Color.rgb(20,40,70); paint.textSize=24f; paint.isFakeBoldText=true; canvas.drawText("CHRONOS SCREEN",40f,55f,paint)
        paint.textSize=12f; paint.isFakeBoldText=false; paint.color=Color.DKGRAY; canvas.drawText("Screen-time and digital wellbeing report",40f,78f,paint)
        val df=SimpleDateFormat("dd MMM yyyy HH:mm",Locale.getDefault()); canvas.drawText("Period: ${df.format(Date(start))} - ${df.format(Date(end))}",40f,108f,paint); canvas.drawText("Total screen time: ${formatDuration(total)}",40f,132f,paint)
        paint.textSize=14f; paint.isFakeBoldText=true; canvas.drawText("App activity",40f,170f,paint); paint.isFakeBoldText=false; paint.textSize=11f
        var y=196f; rows.take(35).forEachIndexed { i,r -> canvas.drawText("${i+1}. ${appLabel(r.key).take(32)}",45f,y,paint); canvas.drawText(formatDuration(r.value),390f,y,paint); canvas.drawText("${opens[r.key] ?: 0} openings",470f,y,paint); y+=17f }
        paint.textSize=9f; paint.color=Color.GRAY; canvas.drawText("Generated on this device. Website history is not collected.",40f,810f,paint)
        doc.finishPage(page); val out=java.io.ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray()
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==71 && resultCode==RESULT_OK) data?.data?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(pendingPdf ?: byteArrayOf()) }; Toast.makeText(this,"PDF report saved",Toast.LENGTH_LONG).show() } }

    private fun createNotificationChannel() { if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("target_alert","Screen-time alerts",NotificationManager.IMPORTANCE_DEFAULT)) }
    private fun formatDuration(ms:Long):String { val m=ms/60000; return if(m/60>0) "${m/60}h ${m%60}m" else "${m}m" }
    private fun addText(parent:LinearLayout,value:String,size:Int,color:Int,bold:Boolean=false) { parent.addView(TextView(this).apply { text=value; textSize=size.toFloat(); setTextColor(color); if(bold)setTypeface(null,android.graphics.Typeface.BOLD); setPadding(0,4,0,4) }) }
    private fun space(parent:LinearLayout,h:Int) { parent.addView(View(this),LinearLayout.LayoutParams(1,h)) }
    private fun card(parent:LinearLayout,content:LinearLayout.()->Unit) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(panel) }; val p=LinearLayout.LayoutParams(-1,-2); p.bottomMargin=8; parent.addView(box,p); box.content() }
    private fun actionButton(parent:LinearLayout,label:String,selected:Boolean=false,action:()->Unit) { val b=Button(this).apply { text=label; isAllCaps=false; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(if(selected) accent else Color.rgb(45,61,83))); setOnClickListener{action()} }; val p=LinearLayout.LayoutParams(if(parent.orientation==LinearLayout.HORIZONTAL) 0 else -1,-2,if(parent.orientation==LinearLayout.HORIZONTAL) 1f else 0f); p.setMargins(3,3,3,3); parent.addView(b,p) }
}
