# Chronos Screen

A privacy-first Android screen-time and digital-wellbeing tracker.

## Features
- Daily, weekly and monthly screen-time summaries
- Per-app foreground time, readable app labels and installed app icons
- Per-app opening counts
- Adjustable daily screen-time limit
- Wellbeing check-in for social-app time and late-night use
- PDF report export using Android's document picker
- Local-only processing; no website history, message or page-content collection
- Guided Android Usage Access permission screen

## Build
Open this repository's GitHub Actions tab and run **Build Chronos Screen APK**. The workflow extracts `chronos-screen-complete-project.zip`, builds the debug APK with JDK 17 / Gradle 8.9, and uploads `app-debug.apk` as an artifact.

## Install and permission
Install the downloaded debug APK. On first launch, tap **Enable Usage Access**, select **Chronos Screen** in Android Usage Access settings, enable **Permit usage access**, then return to the app.

## Privacy and limitations
Android Usage Access provides app-level foreground usage events. It does not grant access to websites visited in Chrome or other browsers. Chronos Screen therefore reports browser app time and openings only, not browsing history. Usage data is processed locally on the device.
