# Chronos Screen

A local-first Android screen-time dashboard.

## Features
- Daily, weekly and monthly foreground-usage summaries
- Per-app usage ranking
- App-opening event count (Android 10+ uses `ACTIVITY_RESUMED`)
- User-configurable daily target
- Notification when the target is reached while the app is open
- CSV export using Android's document picker
- Dark dashboard
- No account, password, cloud service, or network permission

## Build APK with GitHub Actions
1. Upload the project files to the root of a GitHub repository, preserving folders.
2. Ensure `.github/workflows/build-apk.yml` is present.
3. Open the repository's **Actions** tab.
4. Select **Build Chronos Screen APK**.
5. Tap **Run workflow** if it has not started automatically.
6. When completed, open the run and download the `chronos-screen-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk`.

## First run on Android
1. Open Chronos Screen.
2. Tap **Grant Usage Access**.
3. In Android's Usage Access screen, select Chronos Screen and enable permission.
4. Return to Chronos Screen and refresh.
5. Set the daily target.
6. Grant notification permission if Android asks.

## Important notes
- Android Usage Access is a special app permission. It is not a login or GitHub permission.
- Usage data is read on-device through `UsageStatsManager`; this project has no internet permission and does not upload usage data.
- Daily target notifications are checked when the dashboard is opened/refreshed. This starter version does not run a background monitoring service.
- Usage data may be delayed or aggregated by Android. App-opening count uses foreground activity-resumed events and is an approximate activity-launch count, not a guaranteed count of every tap.
- This initial release targets Android API 35 and requires Android 8.0 (API 26) or newer.
- The workflow builds a debug APK for testing, not a Play Store release.
