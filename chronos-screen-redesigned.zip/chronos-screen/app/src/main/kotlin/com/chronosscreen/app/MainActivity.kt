package com.chronosscreen.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.AppOpsManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 26)
    private val panel = Color.rgb(24, 33, 49)
    private val accent = Color.rgb(77, 164, 255)
    private val cyan = Color.rgb(72, 220, 220)
    private val muted = Color.rgb(164, 180, 202)
    private lateinit var root: LinearLayout
    private lateinit var usageManager: UsageStatsManager
    private var range = Range.DAY
    private enum class Range { DAY, WEEK, MONTH }
    private var pendingPdf: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usageManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        createNotificationChannel()
        render()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 22, 18, 28) }
        val scroll = ScrollView(this).apply { isFillViewport = true }; scroll.addView(root); setContentView(scroll)

        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply { text = "⌛"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(Color.rgb(39,143,190), 18); setPadding(10,8,10,8) }
        brand.addView(mark, LinearLayout.LayoutParams(54,54))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0) }
        addText(heading, "Chronos Screen", 22, Color.WHITE, true)
        addText(heading, "Your time. Your control.", 12, muted)
        brand.addView(heading, LinearLayout.LayoutParams(0,-2,1f))
        val settings = TextView(this).apply { text = "⚙"; textSize = 23f; setTextColor(muted); gravity = Gravity.CENTER; setOnClickListener { editTarget(getSharedPreferences("chronos", MODE_PRIVATE).getInt("target_minutes",240)) } }
        brand.addView(settings, LinearLayout.LayoutParams(42,48)); root.addView(brand); space(root,20)

        if (!hasUsageAccess()) {
            card(root) {
                addText(this, "Welcome to Chronos 👋", 22, Color.WHITE, true)
                addText(this, "See how you spend time on your phone. Track app usage, daily screen time and app openings in one simple dashboard.", 14, muted)
                space(this, 12)
                actionButton(this, "Enable usage access", true) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                space(this, 8)
                addText(this, "Your privacy matters: Chronos does not read messages or collect website browsing history. Usage data stays on this device.", 12, muted)
            }
            addText(root, "Next step", 16, Color.WHITE, true)
            addText(root, "Android Settings → Chronos Screen → Allow usage access. Then return to this app.", 13, muted)
            return
        }

        val start = rangeStart(range); val end = System.currentTimeMillis()
        val usage = aggregate(start, end).filter { it.value > 0 && it.key != packageName }
        val openings = countLaunchesByApp(start, end)
        val total = usage.values.sum()
        val target = getSharedPreferences("chronos", MODE_PRIVATE).getInt("target_minutes", 240)
        val targetMs = target * 60_000L
        val ranked = usage.entries.sortedByDescending { it.value }
        val top = ranked.firstOrNull()
        val lateNight = calculateLateNight(start, end)
        val social = ranked.filter { isSocial(it.key) }.sumOf { it.value }

        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(Color.rgb(22,31,47), 18); setPadding(4,4,4,4) }
        listOf("Today", "Week", "Month").forEachIndexed { i, label ->
            val b = TextView(this).apply { text=label; textSize=13f; gravity=Gravity.CENTER; setTextColor(if(range.ordinal==i) Color.WHITE else muted); background=if(range.ordinal==i) rounded(Color.rgb(48,119,190),14) else null; setPadding(8,11,8,11); setOnClickListener { range=Range.values()[i]; render() } }
            selector.addView(b, LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(selector); space(root,14)

        val hero = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(19,18,19,18); background=gradient(Color.rgb(27,67,105),Color.rgb(28,43,70),22) }
        addText(hero, when(range){Range.DAY->"TODAY'S SCREEN TIME";Range.WEEK->"THIS WEEK'S SCREEN TIME";Range.MONTH->"THIS MONTH'S SCREEN TIME"},11,Color.rgb(191,220,246),true)
        addText(hero, formatDuration(total), 42, Color.WHITE, true)
        addText(hero, "${openings.values.sum()} times you opened apps", 13, Color.rgb(192,219,242))
        space(hero,14)
        val progressLabel=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        addText(progressLabel,"Daily target",13,Color.WHITE,true)
        val spacer=View(this); progressLabel.addView(spacer,LinearLayout.LayoutParams(0,1,1f))
        addText(progressLabel,"${target/60}h ${target%60}m",13,Color.WHITE,true)
        hero.addView(progressLabel)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=((total.toDouble()/targetMs.coerceAtLeast(1))*100).toInt().coerceIn(0,100); progressTintList=android.content.res.ColorStateList.valueOf(cyan); progressBackgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(68,91,117)) }
        hero.addView(bar,LinearLayout.LayoutParams(-1,10)); space(hero,7)
        addText(hero,"${((total.toDouble()/targetMs.coerceAtLeast(1))*100).toInt()}% of your daily target used",12,Color.rgb(200,222,242))
        actionButton(hero,"Change daily target",false) { editTarget(target) }
        root.addView(hero); space(root,18)

        addText(root,"Your day at a glance",18,Color.WHITE,true); space(root,8)
        val stats=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        statCard(stats,"APP OPENS","${openings.values.sum()}","Launches",Color.rgb(91,180,255))
        statCard(stats,"SOCIAL TIME",formatDuration(social),"Social apps",Color.rgb(188,137,255))
        statCard(stats,"LATE NIGHT",formatDuration(lateNight),"11 PM – 6 AM",Color.rgb(255,179,104))
        root.addView(stats); space(root,18)

        addText(root,"Wellbeing insight",18,Color.WHITE,true); space(root,8)
        card(root) {
            val insight=when {
                top==null -> "Your usage summary will appear here once you start using apps."
                total>=targetMs -> "You've reached your daily target. Try taking a short screen-free break."
                social>total/2 && total>0 -> "Social apps take more than half of your tracked time. Try checking them at set times."
                lateNight>=30*60_000L -> "You spent ${formatDuration(lateNight)} on your phone late at night. Consider a relaxing screen-free routine before sleep."
                else -> "Nice work checking your habits. A 5-minute break after long sessions can help you reset."
            }
            addText(this,"✦  A small suggestion",12,cyan,true)
            addText(this,insight,15,Color.WHITE,true)
            if(top!=null) { space(this,6); addText(this,"Most used: ${appLabel(top.key)} · ${formatDuration(top.value)}",12,muted) }
        }
        space(root,18)
        val appHeader=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        addText(appHeader,"Most-used apps",18,Color.WHITE,true)
        val more=TextView(this).apply { text="TOP 30"; textSize=10f; setTextColor(cyan); gravity=Gravity.CENTER_VERTICAL }
        appHeader.addView(View(this),LinearLayout.LayoutParams(0,1,1f)); appHeader.addView(more)
        root.addView(appHeader); addText(root,"Apps are ranked by time spent",12,muted); space(root,7)
        ranked.take(30).forEachIndexed { i, entry ->
            val info=try{packageManager.getApplicationInfo(entry.key,0)}catch(_:Exception){null}
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,11,12,11); background=rounded(panel,16) }
            val icon=if(info!=null) try{packageManager.getApplicationIcon(info)}catch(_:Exception){null}else null
            if(icon!=null) row.addView(ImageView(this).apply{setImageDrawable(icon)},LinearLayout.LayoutParams(40,40))
            else row.addView(TextView(this).apply{text="${i+1}";textSize=14f;gravity=Gravity.CENTER;setTextColor(cyan);background=rounded(Color.rgb(37,57,78),13)},LinearLayout.LayoutParams(40,40))
            val names=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(11,0,5,0)}
            addText(names,appLabel(entry.key),14,Color.WHITE,true)
            addText(names,"${openings[entry.key]?:0} opens",11,muted)
            row.addView(names,LinearLayout.LayoutParams(0,-2,1f))
            addText(row,formatDuration(entry.value),13,cyan,true)
            val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=7;root.addView(row,lp)
        }
        if(ranked.isEmpty()) card(root){addText(this,"No app activity found for this period yet.",14,muted)}
        space(root,12)
        actionButton(root,"Export PDF report",true){exportPdf(ranked,openings,start,end,total)}
        space(root,5); actionButton(root,"Refresh usage",false){render()}
        space(root,16)
        addText(root,"PRIVACY FIRST",11,cyan,true)
        addText(root,"Chronos measures app usage only. It does not read messages or collect browser history or websites visited. Your report is created on this phone.",11,muted)
    }

    private fun statCard(parent:LinearLayout,label:String,value:String,caption:String,tint:Int) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,12,8,12); background=rounded(panel,16) }
        addText(box,label,9,muted,true); addText(box,value,16,Color.WHITE,true); addText(box,caption,10,tint)
        val lp=LinearLayout.LayoutParams(0,-2,1f);lp.setMargins(3,0,3,0);parent.addView(box,lp)
    }

    private fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (_: Exception) { pkg.substringAfterLast('.') }
    private fun isSocial(pkg: String): Boolean = pkg in setOf("com.instagram.android","com.facebook.katana","com.facebook.orca","com.whatsapp","com.twitter.android","com.snapchat.android","com.linkedin.android","com.zhiliaoapp.musically")

    private fun aggregate(start: Long, end: Long): Map<String, Long> {
        val raw = usageManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyMap()
        val totals = mutableMapOf<String,Long>()
        raw.forEach { if (it.totalTimeInForeground > 0) totals[it.packageName] = (totals[it.packageName] ?: 0L) + it.totalTimeInForeground }
        return totals
    }

    private fun countLaunchesByApp(start: Long, end: Long): Map<String,Int> {
        val events = usageManager.queryEvents(start,end); val event = UsageEvents.Event(); val counts = mutableMapOf<String,Int>()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = if (Build.VERSION.SDK_INT >= 29) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED else event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            if (resumed && event.packageName != packageName) counts[event.packageName] = (counts[event.packageName] ?: 0) + 1
        }
        return counts
    }

    private fun calculateLateNight(start: Long, end: Long): Long {
        val events = usageManager.queryEvents(start,end); val e = UsageEvents.Event(); var total = 0L; var last: Long? = null
        while (events.hasNextEvent()) { events.getNextEvent(e); val fg = if (Build.VERSION.SDK_INT >= 29) e.eventType == UsageEvents.Event.ACTIVITY_RESUMED else e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            val bgEvent = if (Build.VERSION.SDK_INT >= 29) e.eventType == UsageEvents.Event.ACTIVITY_PAUSED || e.eventType == UsageEvents.Event.ACTIVITY_STOPPED else e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            if (fg) last = e.timeStamp else if (bgEvent && last != null) { val c = Calendar.getInstance().apply { timeInMillis = last!! }; if (c.get(Calendar.HOUR_OF_DAY) >= 23 || c.get(Calendar.HOUR_OF_DAY) < 6) total += (e.timeStamp - last!!).coerceAtLeast(0); last = null }
        }; return total
    }

    private fun rangeStart(which: Range): Long { val c = Calendar.getInstance(); when(which) { Range.DAY -> c.set(Calendar.HOUR_OF_DAY,0).also { c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) }; Range.WEEK -> c.set(Calendar.DAY_OF_WEEK,c.firstDayOfWeek).also { c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) }; Range.MONTH -> c.set(Calendar.DAY_OF_MONTH,1).also { c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0) } }; return c.timeInMillis }

    private fun editTarget(current: Int) { val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText((current/60).toString()); hint = "Hours per day" }; AlertDialog.Builder(this).setTitle("Daily screen-time limit").setView(input).setPositiveButton("Save") { _,_ -> val h=input.text.toString().toIntOrNull()?.coerceIn(1,24) ?: 4; getSharedPreferences("chronos",MODE_PRIVATE).edit().putInt("target_minutes",h*60).apply(); render() }.setNegativeButton("Cancel",null).show() }

    private fun exportPdf(rows: List<Map.Entry<String,Long>>, opens: Map<String,Int>, start: Long, end: Long, total: Long) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE,"Chronos-Screen-Report.pdf") }
        pendingPdf = makePdf(rows,opens,start,end,total); startActivityForResult(intent,71)
    }
    private fun makePdf(rows: List<Map.Entry<String,Long>>, opens: Map<String,Int>, start: Long, end: Long, total: Long): ByteArray {
        val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val canvas=page.canvas; val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color=Color.rgb(16,25,42); canvas.drawColor(Color.WHITE); paint.color=Color.rgb(20,40,70); paint.textSize=24f; paint.isFakeBoldText=true; canvas.drawText("CHRONOS SCREEN",40f,55f,paint)
        paint.textSize=12f; paint.isFakeBoldText=false; paint.color=Color.DKGRAY; canvas.drawText("Screen-time and digital wellbeing report",40f,78f,paint)
        val df=SimpleDateFormat("dd MMM yyyy HH:mm",Locale.getDefault()); canvas.drawText("Period: ${df.format(Date(start))} - ${df.format(Date(end))}",40f,108f,paint); canvas.drawText("Total screen time: ${formatDuration(total)}",40f,132f,paint)
        paint.textSize=14f; paint.isFakeBoldText=true; canvas.drawText("App activity",40f,170f,paint); paint.isFakeBoldText=false; paint.textSize=11f
        var y=196f; rows.take(35).forEachIndexed { i,r -> canvas.drawText("${i+1}. ${appLabel(r.key).take(32)}",45f,y,paint); canvas.drawText(formatDuration(r.value),390f,y,paint); canvas.drawText("${opens[r.key] ?: 0} openings",470f,y,paint); y+=17f }
        paint.textSize=9f; paint.color=Color.GRAY; canvas.drawText("Generated on this device. Website history is not collected.",40f,810f,paint)
        doc.finishPage(page); val out=java.io.ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray()
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==71 && resultCode==RESULT_OK) data?.data?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(pendingPdf ?: byteArrayOf()) }; Toast.makeText(this,"PDF report saved",Toast.LENGTH_LONG).show() } }

    private fun createNotificationChannel() { if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("target_alert","Screen-time alerts",NotificationManager.IMPORTANCE_DEFAULT)) }
    private fun formatDuration(ms:Long):String { val m=ms/60000; return if(m/60>0) "${m/60}h ${m%60}m" else "${m}m" }
    private fun rounded(color:Int,radius:Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius=radius.toFloat() }
    private fun gradient(a:Int,b:Int,radius:Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,intArrayOf(a,b)).apply { cornerRadius=radius.toFloat() }
    private fun addText(parent:LinearLayout,value:String,size:Int,color:Int,bold:Boolean=false) { parent.addView(TextView(this).apply { text=value; textSize=size.toFloat(); setTextColor(color); if(bold)setTypeface(null,android.graphics.Typeface.BOLD); setPadding(0,3,0,3) }) }
    private fun space(parent:LinearLayout,h:Int) { parent.addView(View(this),LinearLayout.LayoutParams(1,h)) }
    private fun card(parent:LinearLayout,content:LinearLayout.()->Unit) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,15,16,15); background=rounded(panel,18) }; val p=LinearLayout.LayoutParams(-1,-2); p.bottomMargin=8; parent.addView(box,p); box.content() }
    private fun actionButton(parent:LinearLayout,label:String,selected:Boolean=false,action:()->Unit) { val b=TextView(this).apply { text=label; textSize=14f; gravity=Gravity.CENTER; setPadding(12,12,12,12); setTextColor(Color.WHITE); background=rounded(if(selected) Color.rgb(44,126,190) else Color.rgb(39,54,75),14); setOnClickListener{action()} }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); parent.addView(b,p) }

}
